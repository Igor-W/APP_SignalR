﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesktopClient
{
    public class Message
    {
        public string Text { get; set; }
    }
}
