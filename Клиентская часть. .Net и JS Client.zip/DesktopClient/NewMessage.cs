﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesktopClient
{
    public sealed class NewMessage : Message
    {
        public string Sender { get; set; }
    }
}
